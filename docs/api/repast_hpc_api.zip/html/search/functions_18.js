var searchData=
[
  ['xcor_1144',['xCor',['../classrepast_1_1relogo_1_1_relogo_agent.html#ab6f3b561e616d3c5c0cdf896dbdb83f2',1,'repast::relogo::RelogoAgent::xCor()'],['../classrepast_1_1relogo_1_1_turtle.html#ad2fbb3478a37d234450362d8384fb457',1,'repast::relogo::Turtle::xCor()']]]
];
