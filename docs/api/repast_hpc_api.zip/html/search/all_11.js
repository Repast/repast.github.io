var searchData=
[
  ['query_388',['query',['../classrepast_1_1_grid2_d_query.html#a44d46360d72ba9e7b0114c2cb248ee96',1,'repast::Grid2DQuery::query()'],['../classrepast_1_1_moore2_d_grid_query.html#a830fa7eeb60b2de4ec5046bd95e85f5c',1,'repast::Moore2DGridQuery::query()'],['../classrepast_1_1_v_n2_d_grid_query.html#a5017801cf8036f53f56f1a891acfa186',1,'repast::VN2DGridQuery::query()']]]
];
